// Minimal dependency-free symbol resolver + inline hook (arm64 trampoline, arm32/thumb toggle)
#pragma once
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <mutex>

namespace hk {

struct Query {
    const char *name;
    uintptr_t bias;
    const ElfW(Phdr) *ph;
    int n;
    bool ok;
};

static int iterCb(struct dl_phdr_info *i, size_t, void *d) {
    Query *q = (Query *) d;
    if (!i->dlpi_name || !*i->dlpi_name) return 0;
    size_t L = strlen(i->dlpi_name), l = strlen(q->name);
    if (L < l || strcmp(i->dlpi_name + L - l, q->name)) return 0;
    if (L > l && i->dlpi_name[L - l - 1] != '/') return 0;
    q->bias = i->dlpi_addr;
    q->ph = i->dlpi_phdr;
    q->n = i->dlpi_phnum;
    q->ok = true;
    return 1;
}

static bool findModule(const char *name, Query &q) {
    q = Query{name, 0, nullptr, 0, false};
    dl_iterate_phdr(iterCb, &q);
    return q.ok;
}

static bool hasModule(const char *name) {
    Query q;
    return findModule(name, q);
}

static void *resolve(const char *lib, const char *sym) {
    Query q;
    if (!findModule(lib, q)) return nullptr;
    const ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < q.n; i++)
        if (q.ph[i].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *) (q.bias + q.ph[i].p_vaddr); break; }
    if (!dyn) return nullptr;
    auto fix = [&](uintptr_t p) { return p < q.bias ? p + q.bias : p; };
    uintptr_t symtab = 0, strtab = 0, strsz = 0;
    for (const ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        if (d->d_tag == DT_SYMTAB) symtab = fix(d->d_un.d_ptr);
        else if (d->d_tag == DT_STRTAB) strtab = fix(d->d_un.d_ptr);
        else if (d->d_tag == DT_STRSZ) strsz = d->d_un.d_val;
    }
    if (!symtab || !strtab || !strsz) return nullptr;
    size_t n = strtab > symtab ? (strtab - symtab) / sizeof(ElfW(Sym)) : 20000;
    if (n > 200000) n = 200000;
    const ElfW(Sym) *st = (const ElfW(Sym) *) symtab;
    const char *str = (const char *) strtab;
    for (size_t i = 1; i < n; i++) {
        const ElfW(Sym) &s = st[i];
        if (s.st_shndx == SHN_UNDEF || !s.st_name || s.st_name >= strsz) continue;
        if (ELF64_ST_TYPE(s.st_info) != STT_FUNC) continue;
        if (!strcmp(str + s.st_name, sym)) return (void *) (q.bias + s.st_value);
    }
    return nullptr;
}

static bool writeCode(void *addr, const void *data, size_t n) {
    uintptr_t a = (uintptr_t) addr & ~(uintptr_t) 1;
    uintptr_t ps = (uintptr_t) sysconf(_SC_PAGESIZE);
    uintptr_t p0 = a & ~(ps - 1);
    size_t len = ((a + n + ps - 1) & ~(ps - 1)) - p0;
    if (mprotect((void *) p0, len, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) return false;
    memcpy((void *) a, data, n);
    __builtin___clear_cache((char *) a, (char *) (a + n));
    mprotect((void *) p0, len, PROT_READ | PROT_EXEC);
    return true;
}

struct Hook {
    void *target = nullptr;
    void *repl = nullptr;
    void *tramp = nullptr;  // mode 1
    uint8_t saved[16] = {0};
    uint8_t patch[16] = {0};
    size_t plen = 0;
    int mode = 0;  // 1 = trampoline, 2 = toggle
    std::mutex mu;
    int inflight = 0;
};

static bool isPcRel(uint32_t i) {
    if ((i & 0x7C000000) == 0x14000000) return true;  // B / BL
    if ((i & 0xFF000010) == 0x54000000) return true;  // B.cond
    if ((i & 0x7E000000) == 0x34000000) return true;  // CBZ / CBNZ
    if ((i & 0x7E000000) == 0x36000000) return true;  // TBZ / TBNZ
    if ((i & 0x1F000000) == 0x10000000) return true;  // ADR / ADRP
    if ((i & 0x3B000000) == 0x18000000) return true;  // LDR literal
    return false;
}

// returns 0 on failure, 1 = *orig is a trampoline, 2 = caller must call through a toggle wrapper
static int prepare(Hook &h, void *target, void *repl, void **orig) {
    h.target = target;
    h.repl = repl;
    uint8_t *real = (uint8_t *) ((uintptr_t) target & ~(uintptr_t) 1);
#if defined(__aarch64__)
    h.plen = 16;
    uint32_t p[4] = {0x58000050, 0xD61F0200, 0, 0};  // ldr x16,#8 ; br x16 ; .quad repl
    *(uint64_t *) (p + 2) = (uint64_t) repl;
    memcpy(h.patch, p, 16);
    memcpy(h.saved, real, 16);
    const uint32_t *c = (const uint32_t *) real;
    bool rel = false;
    for (int i = 0; i < 4; i++) rel |= isPcRel(c[i]);
    if (!rel) {
        void *t = mmap(nullptr, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (t != MAP_FAILED) {
            uint32_t *tp = (uint32_t *) t;
            memcpy(tp, c, 16);
            tp[4] = 0x58000050;
            tp[5] = 0xD61F0200;
            *(uint64_t *) (tp + 6) = (uint64_t) real + 16;
            __builtin___clear_cache((char *) t, (char *) t + 32);
            if (mprotect(t, 4096, PROT_READ | PROT_EXEC) == 0) {
                h.tramp = t;
                *orig = t;
                h.mode = 1;
                return 1;
            }
        }
    }
    h.mode = 2;
    return 2;
#elif defined(__arm__)
    bool thumb = ((uintptr_t) target & 1) != 0;
    if (!thumb) {
        uint32_t p[2] = {0xE51FF004, (uint32_t) (uintptr_t) repl};  // ldr pc,[pc,#-4]
        memcpy(h.patch, p, 8);
        h.plen = 8;
    } else if (((uintptr_t) real & 3) == 0) {
        uint16_t p[2] = {0xF8DF, 0xF000};  // ldr.w pc,[pc]
        memcpy(h.patch, p, 4);
        uint32_t r = (uint32_t) (uintptr_t) repl | 1;
        memcpy(h.patch + 4, &r, 4);
        h.plen = 8;
    } else {
        uint16_t p[3] = {0xBF00, 0xF8DF, 0xF000};  // nop ; ldr.w pc,[pc]
        memcpy(h.patch, p, 6);
        uint32_t r = (uint32_t) (uintptr_t) repl | 1;
        memcpy(h.patch + 6, &r, 4);
        h.plen = 10;
    }
    memcpy(h.saved, real, h.plen);
    h.mode = 2;
    return 2;
#else
    return 0;
#endif
}

static bool enable(Hook &h) { return writeCode(h.target, h.patch, h.plen); }

// toggle mode: original bytes are in place while any call is in flight
struct Guard {
    Hook &h;
    explicit Guard(Hook &hh) : h(hh) {
        std::lock_guard<std::mutex> l(h.mu);
        if (h.inflight++ == 0) writeCode(h.target, h.saved, h.plen);
    }
    ~Guard() {
        std::lock_guard<std::mutex> l(h.mu);
        if (--h.inflight == 0) writeCode(h.target, h.patch, h.plen);
    }
};

}  // namespace hk
