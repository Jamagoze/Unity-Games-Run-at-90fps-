// Unity FPS Unlock - Zygisk module
// Runs 30/60fps-locked Unity games at a higher render rate (default 90):
//  - hooks il2cpp_runtime_invoke / mono_runtime_invoke and skips Update/LateUpdate on
//    "in-between" frames so game logic keeps its original tick rate
//  - drives Time.timeScale per frame so Time.deltaTime stays correct on tick frames
//  - interpolates the camera (Camera.main or a static field) on every frame
#include <jni.h>
#include <android/log.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <time.h>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include "zygisk.hpp"
#include "dobby.h"

#define TAG "UnityFps"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ---------------------------------------------------------------- config
struct Cfg {
    int target = 90;
    int base = 0;  // 0 = auto
    int camera = 1;  // 0 off, 1 Camera.main, 2 custom static field
    std::string camClass, camField;
    int camComps = 2;
    bool inputWake = true;
    float snap = 0.f;
    bool verbose = false;
};
static Cfg g_cfg;

typedef std::map<std::string, std::string> Kv;

static std::string trim(const std::string &s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static std::map<std::string, Kv> parseCfg(const std::string &txt) {
    std::map<std::string, Kv> out;
    std::istringstream is(txt);
    std::string line, sec;
    out[""];
    while (std::getline(is, line)) {
        size_t h = line.find('#');
        if (h != std::string::npos) line = line.substr(0, h);
        line = trim(line);
        if (line.empty()) continue;
        if (line[0] == '[') {
            size_t e = line.find(']');
            sec = trim(line.substr(1, e == std::string::npos ? std::string::npos : e - 1));
            out[sec];
            continue;
        }
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        out[sec][trim(line.substr(0, eq))] = trim(line.substr(eq + 1));
    }
    return out;
}

static std::string readFd(int fd) {
    std::string s;
    char b[1024];
    ssize_t n;
    while ((n = read(fd, b, sizeof b)) > 0) s.append(b, (size_t) n);
    return s;
}

static void applyCfg(const Kv &kv) {
    auto get = [&](const char *k) -> std::string {
        auto it = kv.find(k);
        return it == kv.end() ? "" : it->second;
    };
    std::string v;
    if (!(v = get("target_fps")).empty()) g_cfg.target = atoi(v.c_str());
    if (!(v = get("base_fps")).empty()) g_cfg.base = (v == "auto") ? 0 : atoi(v.c_str());
    if (!(v = get("camera")).empty()) g_cfg.camera = (v == "off") ? 0 : (v == "custom") ? 2 : 1;
    if (!(v = get("input_wake")).empty()) g_cfg.inputWake = atoi(v.c_str()) != 0;
    if (!(v = get("snap")).empty()) g_cfg.snap = (float) atof(v.c_str());
    if (!(v = get("verbose")).empty()) g_cfg.verbose = atoi(v.c_str()) != 0;
    g_cfg.camClass = get("cam_class");
    g_cfg.camField = get("cam_field");
    if (get("cam_type") == "vec3") g_cfg.camComps = 3;
    if (g_cfg.target < 30) g_cfg.target = 90;
    if (g_cfg.camera == 2 && (g_cfg.camClass.empty() || g_cfg.camField.empty())) g_cfg.camera = 1;
}

// ---------------------------------------------------------------- runtime adapter
static bool g_il2 = false;
static const char *g_lib = nullptr;
static void *(*orig_invoke)(void *, void *, void **, void **) = nullptr;

// il2cpp
static void *(*il_domain_get)() = nullptr;
static void **(*il_domain_asms)(void *, size_t *) = nullptr;
static void *(*il_asm_img)(void *) = nullptr;
static void *(*il_cls_from)(void *, const char *, const char *) = nullptr;
static void *(*il_meth)(void *, const char *, int) = nullptr;
static const char *(*il_mname)(void *) = nullptr;
static uint32_t (*il_pcount)(void *) = nullptr;
static void *(*il_unbox)(void *) = nullptr;
static void *(*il_field)(void *, const char *) = nullptr;
static void (*il_sget)(void *, void *) = nullptr;
static void (*il_sset)(void *, void *) = nullptr;
static void (*il_cinit)(void *) = nullptr;
// mono
static void *(*mo_domain_get)() = nullptr;
static void (*mo_foreach)(void (*)(void *, void *), void *) = nullptr;
static void *(*mo_asm_img)(void *) = nullptr;
static void *(*mo_cls_from)(void *, const char *, const char *) = nullptr;
static void *(*mo_meth)(void *, const char *, int) = nullptr;
static const char *(*mo_mname)(void *) = nullptr;
static void *(*mo_sig)(void *) = nullptr;
static uint32_t (*mo_sigpc)(void *) = nullptr;
static void *(*mo_unbox)(void *) = nullptr;
static void *(*mo_field)(void *, const char *) = nullptr;
static void *(*mo_vtable)(void *, void *) = nullptr;
static void (*mo_sget)(void *, void *, void *) = nullptr;
static void (*mo_sset)(void *, void *, void *) = nullptr;

#define RES(var, name) var = (decltype(var)) DobbySymbolResolver(g_lib, name)

static bool resolveRt() {
    if (g_il2) {
        RES(il_domain_get, "il2cpp_domain_get");
        RES(il_domain_asms, "il2cpp_domain_get_assemblies");
        RES(il_asm_img, "il2cpp_assembly_get_image");
        RES(il_cls_from, "il2cpp_class_from_name");
        RES(il_meth, "il2cpp_class_get_method_from_name");
        RES(il_mname, "il2cpp_method_get_name");
        RES(il_pcount, "il2cpp_method_get_param_count");
        RES(il_unbox, "il2cpp_object_unbox");
        RES(il_field, "il2cpp_class_get_field_from_name");
        RES(il_sget, "il2cpp_field_static_get_value");
        RES(il_sset, "il2cpp_field_static_set_value");
        RES(il_cinit, "il2cpp_runtime_class_init");
        return il_domain_get && il_domain_asms && il_asm_img && il_cls_from && il_meth &&
               il_mname && il_pcount && il_unbox;
    }
    RES(mo_domain_get, "mono_domain_get");
    RES(mo_foreach, "mono_assembly_foreach");
    RES(mo_asm_img, "mono_assembly_get_image");
    RES(mo_cls_from, "mono_class_from_name");
    RES(mo_meth, "mono_class_get_method_from_name");
    RES(mo_mname, "mono_method_get_name");
    RES(mo_sig, "mono_method_signature");
    RES(mo_sigpc, "mono_signature_get_param_count");
    RES(mo_unbox, "mono_object_unbox");
    RES(mo_field, "mono_class_get_field_from_name");
    RES(mo_vtable, "mono_class_vtable");
    RES(mo_sget, "mono_field_static_get_value");
    RES(mo_sset, "mono_field_static_set_value");
    return mo_domain_get && mo_foreach && mo_asm_img && mo_cls_from && mo_meth && mo_mname &&
           mo_sig && mo_sigpc && mo_unbox;
}

static const char *rt_mname(void *m) { return g_il2 ? il_mname(m) : mo_mname(m); }

static int rt_pcount(void *m) {
    if (g_il2) return (int) il_pcount(m);
    void *s = mo_sig(m);
    return s ? (int) mo_sigpc(s) : -1;
}

static void *rt_unbox(void *o) { return g_il2 ? il_unbox(o) : mo_unbox(o); }

static std::vector<void *> g_monoImgs;
static void monoCb(void *a, void *) { g_monoImgs.push_back(mo_asm_img(a)); }

static void *rt_class(const char *ns, const char *name) {
    if (g_il2) {
        size_t n = 0;
        void **as = il_domain_asms(il_domain_get(), &n);
        for (size_t i = 0; i < n; i++) {
            void *k = il_cls_from(il_asm_img(as[i]), ns, name);
            if (k) return k;
        }
        return nullptr;
    }
    g_monoImgs.clear();
    mo_foreach(monoCb, nullptr);
    for (void *img : g_monoImgs) {
        void *k = mo_cls_from(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}

static void *rt_classFull(const std::string &full) {
    size_t d = full.rfind('.');
    if (d == std::string::npos) return rt_class("", full.c_str());
    return rt_class(full.substr(0, d).c_str(), full.substr(d + 1).c_str());
}

static void *rt_method(void *k, const char *n, int argc) {
    if (!k) return nullptr;
    return g_il2 ? il_meth(k, n, argc) : mo_meth(k, n, argc);
}

// ---------------------------------------------------------------- Unity API
struct V3 { float x, y, z; };

struct Api {
    void *mSetScale = nullptr, *mGetScale = nullptr, *mSetTfr = nullptr, *mGetTfr = nullptr;
    void *mSetVsync = nullptr, *mGetVsync = nullptr, *mGetFc = nullptr;
    void *mCamMain = nullptr, *mGetTr = nullptr, *mGetPos = nullptr, *mSetPos = nullptr;
    void *mAnyKey = nullptr, *mMouseUp = nullptr;
    void *cField = nullptr, *cVt = nullptr;
    void *camTr = nullptr;
} A;

static bool g_exc = false;

static void *call(void *m, void *obj, void **args) {
    void *exc = nullptr;
    void *r = orig_invoke(m, obj, args, &exc);
    g_exc = exc != nullptr;
    return g_exc ? nullptr : r;
}

static bool getF(void *m, float &o) {
    void *r = call(m, nullptr, nullptr);
    if (!r) return false;
    o = *(float *) rt_unbox(r);
    return true;
}

static bool getI(void *m, int &o) {
    void *r = call(m, nullptr, nullptr);
    if (!r) return false;
    o = *(int *) rt_unbox(r);
    return true;
}

static void setF(void *m, float v) { void *a[1] = {&v}; call(m, nullptr, a); }
static void setI(void *m, int v) { void *a[1] = {&v}; call(m, nullptr, a); }

static bool initApi() {
    void *kTime = rt_class("UnityEngine", "Time");
    void *kApp = rt_class("UnityEngine", "Application");
    void *kQs = rt_class("UnityEngine", "QualitySettings");
    A.mSetScale = rt_method(kTime, "set_timeScale", 1);
    A.mGetScale = rt_method(kTime, "get_timeScale", 0);
    A.mGetFc = rt_method(kTime, "get_frameCount", 0);
    A.mSetTfr = rt_method(kApp, "set_targetFrameRate", 1);
    A.mGetTfr = rt_method(kApp, "get_targetFrameRate", 0);
    A.mSetVsync = rt_method(kQs, "set_vSyncCount", 1);
    A.mGetVsync = rt_method(kQs, "get_vSyncCount", 0);
    if (!A.mSetScale || !A.mGetScale || !A.mGetFc || !A.mSetTfr || !A.mGetTfr) {
        LOGE("core Unity API not found");
        return false;
    }
    if (g_cfg.camera == 1) {
        void *kCam = rt_class("UnityEngine", "Camera");
        void *kComp = rt_class("UnityEngine", "Component");
        void *kTr = rt_class("UnityEngine", "Transform");
        A.mCamMain = rt_method(kCam, "get_main", 0);
        A.mGetTr = rt_method(kComp, "get_transform", 0);
        A.mGetPos = rt_method(kTr, "get_position", 0);
        A.mSetPos = rt_method(kTr, "set_position", 1);
        if (!A.mCamMain || !A.mGetTr || !A.mGetPos || !A.mSetPos) {
            LOGE("camera API not found, camera interpolation off");
            g_cfg.camera = 0;
        }
    } else if (g_cfg.camera == 2) {
        void *k = rt_classFull(g_cfg.camClass);
        if (k) {
            if (g_il2) {
                if (il_cinit) il_cinit(k);
                A.cField = il_field ? il_field(k, g_cfg.camField.c_str()) : nullptr;
            } else {
                A.cField = mo_field ? mo_field(k, g_cfg.camField.c_str()) : nullptr;
                A.cVt = mo_vtable ? mo_vtable(mo_domain_get(), k) : nullptr;
            }
        }
        bool ok = A.cField && (g_il2 ? (il_sget && il_sset) : (A.cVt && mo_sget && mo_sset));
        if (!ok) {
            LOGE("custom camera field %s.%s not found, camera interpolation off",
                 g_cfg.camClass.c_str(), g_cfg.camField.c_str());
            g_cfg.camera = 0;
        }
    }
    if (g_cfg.inputWake) {
        void *kIn = rt_class("UnityEngine", "Input");
        A.mAnyKey = rt_method(kIn, "get_anyKeyDown", 0);
        A.mMouseUp = rt_method(kIn, "GetMouseButtonUp", 1);
    }
    LOGI("api ready (%s) target=%d base=%d camera=%d", g_il2 ? "il2cpp" : "mono", g_cfg.target,
         g_cfg.base, g_cfg.camera);
    return true;
}

// ---------------------------------------------------------------- state
static std::atomic<int> g_mainTid{0};
static bool g_apiTried = false, g_apiOk = false, g_dead = false;
static std::once_flag g_once;
static std::mutex g_mu;
static std::unordered_map<void *, uint8_t> g_kind;
static thread_local int t_depth = 0;

static uint64_t g_f = 0, g_lastNs = 0;
static int g_fc = -1;
static bool g_active = false, g_tick = true, g_prevTick = false;
static int g_base = 0, g_setTfr = -9999;
static int g_calls = 0, g_callsPrev = 0;
static float g_gs = 1.f, g_lastSet = -1.f;
static bool g_gsInit = false, g_inputDead = false;
static uint64_t g_gated = 0, g_ticks = 0;

static uint64_t nowNs() {
    timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t) t.tv_sec * 1000000000ull + (uint64_t) t.tv_nsec;
}

static inline bool tickAt(uint64_t f) {
    uint64_t b = (uint64_t) g_base, t = (uint64_t) g_cfg.target;
    return (f + 1) * b / t > f * b / t;
}

static inline float alphaAt(uint64_t f) {
    uint64_t b = (uint64_t) g_base, t = (uint64_t) g_cfg.target;
    return (float) (((f + 1) * b) % t) / (float) t;
}

// ---------------------------------------------------------------- camera
struct Cam {
    bool have = false, overridden = false, armed = false, snap = false;
    V3 prev{}, cur{}, written{};
    float ema = 0.f;
} C;

static bool camRead(V3 &v) {
    if (g_cfg.camera == 2) {
        float b[4] = {0, 0, 0, 0};
        if (g_il2) il_sget(A.cField, b); else mo_sget(A.cVt, A.cField, b);
        v = {b[0], b[1], g_cfg.camComps == 3 ? b[2] : 0.f};
        return true;
    }
    if (!A.camTr) return false;
    void *o = call(A.mGetPos, A.camTr, nullptr);
    if (!o) { A.camTr = nullptr; return false; }
    v = *(V3 *) rt_unbox(o);
    return true;
}

static bool camWrite(const V3 &v) {
    if (g_cfg.camera == 2) {
        float b[4] = {v.x, v.y, v.z, 0};
        if (g_il2) il_sset(A.cField, b); else mo_sset(A.cVt, A.cField, b);
        return true;
    }
    if (!A.camTr) return false;
    V3 t = v;
    void *a[1] = {&t};
    call(A.mSetPos, A.camTr, a);
    if (g_exc) { A.camTr = nullptr; return false; }
    return true;
}

static bool nearV(const V3 &a, const V3 &b) {
    float e = 1e-4f * (1.f + fabsf(a.x) + fabsf(a.y) + fabsf(a.z));
    return fabsf(a.x - b.x) <= e && fabsf(a.y - b.y) <= e && fabsf(a.z - b.z) <= e;
}

static void camRefresh(uint64_t f) {
    if (g_cfg.camera != 1) return;
    if (A.camTr && f % 120) return;
    void *c = call(A.mCamMain, nullptr, nullptr);
    if (!c) return;
    void *t = call(A.mGetTr, c, nullptr);
    if (t) A.camTr = t;
}

static void camApply(float alpha) {
    V3 o;
    if (C.snap) o = C.cur;
    else o = {C.prev.x + (C.cur.x - C.prev.x) * alpha, C.prev.y + (C.cur.y - C.prev.y) * alpha,
              C.prev.z + (C.cur.z - C.prev.z) * alpha};
    if (!camWrite(o)) return;
    V3 w;
    C.written = camRead(w) ? w : o;
    C.overridden = true;
}

// put the real camera position back before game scripts run
static void camFinalize() {
    if (g_cfg.camera == 0) return;
    V3 p;
    if (C.overridden) {
        if (camRead(p)) {
            if (nearV(p, C.written)) camWrite(C.cur);
            else C.cur = p;  // moved by scripts after our override
        }
        C.overridden = false;
    } else if (C.armed) {
        if (camRead(p)) { C.prev = C.cur; C.cur = p; C.have = true; }
    }
    C.armed = false;
}

static void camBegin(uint64_t f, bool tick) {
    if (g_cfg.camera == 0 || !g_active) return;
    camRefresh(f);
    if (!C.have) {
        V3 p;
        if (!camRead(p)) return;
        C.prev = C.cur = p;
        C.have = true;
    }
    if (tick) C.armed = true;
    else camApply(alphaAt(f));
}

// called right after the last script call of a tick frame
static void camAfterScripts() {
    V3 p;
    if (!camRead(p)) return;
    C.prev = C.cur;
    C.cur = p;
    float dx = C.cur.x - C.prev.x, dy = C.cur.y - C.prev.y, dz = C.cur.z - C.prev.z;
    float step = sqrtf(dx * dx + dy * dy + dz * dz);
    float th = g_cfg.snap > 0.f ? g_cfg.snap : C.ema * 8.f + 1.f;
    C.snap = step > th;
    C.ema = C.ema * 0.9f + step * 0.1f;
    C.armed = false;
    camApply(alphaAt(g_f - 1));
}

// ---------------------------------------------------------------- frame logic
static bool inputEvent() {
    if (g_inputDead) return false;
    bool b = false;
    if (A.mAnyKey) {
        void *o = call(A.mAnyKey, nullptr, nullptr);
        if (g_exc) { g_inputDead = true; return false; }
        if (o) b = *(uint8_t *) rt_unbox(o) != 0;
    }
    if (!b && A.mMouseUp) {
        int btn = 0;
        void *a[1] = {&btn};
        void *o = call(A.mMouseUp, nullptr, a);
        if (g_exc) { g_inputDead = true; return false; }
        if (o) b = *(uint8_t *) rt_unbox(o) != 0;
    }
    return b;
}

static void fpsEnforce(uint64_t f) {
    if (f % 15) return;
    int tfr = -1, vs = 0;
    if (!getI(A.mGetTfr, tfr)) return;
    if (A.mGetVsync) getI(A.mGetVsync, vs);
    if (tfr != g_setTfr) {  // the game (or nobody yet) controls it
        if (g_cfg.base > 0) g_base = g_cfg.base;
        else if (tfr >= 10 && tfr < g_cfg.target) g_base = tfr;
        else if (tfr >= g_cfg.target) g_base = tfr;
        else g_base = vs > 0 ? 60 / vs : 30;
    }
    g_active = g_base > 0 && g_base < g_cfg.target;
    if (g_active) {
        if (tfr != g_cfg.target) setI(A.mSetTfr, g_cfg.target);
        g_setTfr = g_cfg.target;
        if (vs != 0 && A.mSetVsync) setI(A.mSetVsync, 0);
    } else {
        g_setTfr = tfr;
    }
}

// Time.timeScale for the NEXT frame: tick frames get scale*target/base, others ~0
static void scaleUpdate(uint64_t fn) {
    float cur;
    if (!getF(A.mGetScale, cur)) return;
    if (!g_gsInit || fabsf(cur - g_lastSet) > 1e-5f) { g_gs = cur; g_gsInit = true; }
    float s;
    if (!g_active) s = g_gs;
    else if (g_gs <= 0.f) s = 0.f;
    else s = tickAt(fn) ? g_gs * ((float) g_cfg.target / (float) g_base) : 1e-6f;
    if (fabsf(s - cur) > 1e-9f) setF(A.mSetScale, s);
    g_lastSet = s;
}

static void onNewFrame() {
    uint64_t f = g_f++;
    if (g_prevTick) g_callsPrev = g_calls;
    camFinalize();
    fpsEnforce(f);
    bool tick = true;
    if (g_active) {
        tick = tickAt(f);
        if (!tick && g_cfg.inputWake && inputEvent()) tick = true;
    }
    g_tick = tick;
    g_prevTick = tick;
    g_calls = 0;
    if (tick) g_ticks++;
    scaleUpdate(f + 1);
    camBegin(f, tick);
    if (g_cfg.verbose && f % 300 == 299)
        LOGI("frames=%llu ticks=%llu gated=%llu base=%d active=%d", (unsigned long long) g_f,
             (unsigned long long) g_ticks, (unsigned long long) g_gated, g_base, g_active);
}

// ---------------------------------------------------------------- hook
static uint8_t classify(void *m) {
    std::call_once(g_once, [] {
        if (!resolveRt()) { LOGE("runtime symbols missing"); g_dead = true; }
    });
    if (g_dead) return 0;
    {
        std::lock_guard<std::mutex> l(g_mu);
        auto it = g_kind.find(m);
        if (it != g_kind.end()) return it->second;
    }
    uint8_t k = 0;
    const char *n = rt_mname(m);
    if (n) {
        if (!strcmp(n, "Update")) k = 1;
        else if (!strcmp(n, "LateUpdate")) k = 2;
        if (k && rt_pcount(m) != 0) k = 0;
    }
    std::lock_guard<std::mutex> l(g_mu);
    g_kind[m] = k;
    return k;
}

static void *hk_invoke(void *m, void *obj, void **args, void **exc) {
    if (g_dead || !obj || t_depth > 0) return orig_invoke(m, obj, args, exc);
    if (!classify(m)) return orig_invoke(m, obj, args, exc);
    int tid = (int) syscall(SYS_gettid);
    int zero = 0;
    g_mainTid.compare_exchange_strong(zero, tid);
    if (tid != g_mainTid.load()) return orig_invoke(m, obj, args, exc);
    if (!g_apiOk) {
        if (!g_apiTried) {
            g_apiTried = true;
            g_apiOk = initApi();
            if (!g_apiOk) g_dead = true;
        }
        return orig_invoke(m, obj, args, exc);
    }
    uint64_t t0 = nowNs();
    if (t0 - g_lastNs > 200000) {
        int fc = 0;
        if (getI(A.mGetFc, fc) && fc != g_fc) {
            g_fc = fc;
            onNewFrame();
        }
    }
    if (g_active && !g_tick) {
        g_gated++;
        if (exc) *exc = nullptr;
        g_lastNs = nowNs();
        return nullptr;
    }
    t_depth++;
    void *r = orig_invoke(m, obj, args, exc);
    t_depth--;
    g_calls++;
    if (C.armed && g_active && g_callsPrev > 0 && g_calls == g_callsPrev) camAfterScripts();
    g_lastNs = nowNs();
    return r;
}

// ---------------------------------------------------------------- install
static bool mapsHas(const char *needle) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return false;
    char line[1024];
    bool found = false;
    while (fgets(line, sizeof line, f)) {
        if (strstr(line, needle)) { found = true; break; }
    }
    fclose(f);
    return found;
}

static bool hookRuntime(const char *lib, bool il) {
    const char *sy = il ? "il2cpp_runtime_invoke" : "mono_runtime_invoke";
    void *addr = DobbySymbolResolver(lib, sy);
    if (!addr) return false;
    g_il2 = il;
    g_lib = lib;
    if (DobbyHook(addr, (dobby_dummy_func_t) hk_invoke, (dobby_dummy_func_t *) &orig_invoke) != 0) {
        LOGE("DobbyHook failed for %s", sy);
        g_dead = true;
        return true;
    }
    LOGI("hooked %s in %s", sy, lib);
    return true;
}

static bool tryInstall() {
    if (mapsHas("libil2cpp.so")) return hookRuntime("libil2cpp.so", true);
    static const char *mono[] = {"libmonobdwgc-2.0.so", "libmonosgen-2.0.so", "libmono.so"};
    for (const char *m : mono)
        if (mapsHas(m)) return hookRuntime(m, false);
    return false;
}

static void *watcher(void *) {
    for (int i = 0; i < 4800; i++) {
        if (tryInstall()) return nullptr;
        usleep(50 * 1000);
    }
    return nullptr;
}

// ---------------------------------------------------------------- zygisk
class UnityFps : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { api_ = api; env_ = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        std::string pkg;
        if (args->nice_name) {
            const char *nm = env_->GetStringUTFChars(args->nice_name, nullptr);
            if (nm) { pkg = nm; env_->ReleaseStringUTFChars(args->nice_name, nm); }
        }
        if (pkg.empty() || pkg.find(':') != std::string::npos) { off(); return; }
        std::string txt;
        int fd = open("/data/adb/unity_fps/config.txt", O_RDONLY | O_CLOEXEC);
        if (fd >= 0) { txt = readFd(fd); close(fd); }
        else {
            int d = api_->getModuleDir();
            if (d >= 0) {
                int f = openat(d, "config.txt", O_RDONLY | O_CLOEXEC);
                if (f >= 0) { txt = readFd(f); close(f); }
            }
        }
        if (txt.empty()) { off(); return; }
        auto secs = parseCfg(txt);
        Kv eff = secs[""];
        bool listed = secs.count(pkg) > 0;
        bool all = eff.count("all") && eff["all"] == "1";
        if (!listed && !all) { off(); return; }
        if (listed) for (auto &p : secs[pkg]) eff[p.first] = p.second;
        applyCfg(eff);
        enabled_ = true;
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!enabled_) return;
        pthread_t t;
        if (pthread_create(&t, nullptr, watcher, nullptr) == 0) pthread_detach(t);
    }

private:
    void off() { api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY); }
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool enabled_ = false;
};

REGISTER_ZYGISK_MODULE(UnityFps)
