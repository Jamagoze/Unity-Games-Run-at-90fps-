mkdir -p /data/adb/unity_fps
[ -f /data/adb/unity_fps/config.txt ] || cp "$MODPATH/config.txt" /data/adb/unity_fps/config.txt
ui_print "- Config: /data/adb/unity_fps/config.txt (force-stop the game after editing)"
